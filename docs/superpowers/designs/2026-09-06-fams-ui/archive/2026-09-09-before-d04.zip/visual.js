// Styling and review deep links only. No change to the D0.2 business state machine.
const statusTones = {
  '在库':'info','在用':'info','借出':'info','部门公用':'info',
  '已接收':'success','已完成':'success','已入账':'success','已计入':'success',
  '待交接':'warning','已交出待接收':'warning','待管理员确认':'warning',
  '待库管处理':'warning','库管处理中':'warning','部分完成':'warning',
  '无法满足':'warning','待上传':'warning','待核验':'warning',
  '已过期':'danger','过期失效':'danger','明确拒绝':'danger','身份失效':'danger','未保存':'danger','冲突':'danger',
  '迟到待复核':'warning','时间异常待复核':'warning','旧授权待复核':'warning','已接受 · 原回执':'success'
};
function decorate(){
  document.querySelectorAll('.badge').forEach(el=>el.dataset.tone=statusTones[el.textContent.trim()]||'neutral');
  document.querySelectorAll('.scanbox span').forEach(el=>{if(el.textContent.includes('草图占位'))el.textContent=el.textContent.includes('连续')?'将资产码置于框内 · 连续识别':'将资产码置于框内';});
  document.title=document.title.replace('固定资产草图','FAMS D0.3 视觉稿');
}
new MutationObserver(decorate).observe(document.getElementById('canvas'),{childList:true,subtree:true});
document.querySelector('.reviewbar strong').textContent='FAMS / 视觉设计评审';
document.querySelector('.reviewbar small').textContent='D0.3 · PRD V1.5 · 40 页视觉应用 · 虚构数据';
const designLink=document.querySelector('.reviewbar a');designLink.href='index.html';designLink.textContent='视觉规范与组件库 ↗';
const target=new URLSearchParams(location.search).get('page');
if(new URLSearchParams(location.search).get('present')==='1')document.body.classList.add('presentation');
if(target&&byId[target])navigate(target);
decorate();
