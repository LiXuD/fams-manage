# FAMS D0.3 · UI 设计交付

沿用已有浅色深蓝风格，完成 D0.2 的视觉设计与规范阶段。需求基线 PRD V1.5；40 页与业务状态机保持原样，原始 D0.2 文件未修改。2026-09-08 已通过本地 TalkToFigma MCP 补齐原生 Figma 组件与页面。

2026-09-09 已通过最新频道 `pmnn5fxj` 重新核验全部原生组件与页面，确认与最终交付一致。

2026-09-09 外部评审已完成逐项裁决，见 [D0.4 整改建议](REVIEW-ADJUDICATION-D0.4.md)：纠正现状误判，明确采纳项、优先级与验收条件；建议尚未实施。

## 打开设计

- [Figma 原生稿与实际导出索引](figma-native/index.html)：8 个原生组件集、85 个变体、40 个可编辑画板。
- [Figma 40 页](https://www.figma.com/design/N4BgxhOTtSFpsoxcN7t4XD?node-id=3-5) / [Figma 组件库](https://www.figma.com/design/N4BgxhOTtSFpsoxcN7t4XD?node-id=3-4)。
- [设计系统总览](index.html)：视觉方向、色彩、字体、间距与页面入口。
- [完整组件状态库](component-library.html)：8 个组件族、85 个显式变体、5 类组合模式及交互试验区。
- [40 页视觉画廊](screens.html)：PC 26 页、小程序 14 页，每页有截图和独立画布入口。
- [可点击视觉原型](prototype.html?page=P02)：保留 D0.2 的情境选择和局部业务交互。
- [独立工作台画布](prototype.html?present=1&page=P02)：隐藏画布外的评审工具。

直接双击 HTML 即可使用。也可在项目根目录执行：

```sh
rtk proxy python3 -m http.server 8785 --bind 127.0.0.1 --directory docs/superpowers/designs/2026-09-06-fams-ui
```

然后打开 [本地预览](http://127.0.0.1:8785/index.html)。无需安装依赖或登录。

## 文件与使用

|文件|用途|
|---|---|
|SPECIFICATION.md|视觉规则、组件契约、状态语言和页面模板|
|DEVELOPMENT.md|原生 DOM/CSS 组件接入、属性回调与重建方式|
|tokens.json / tokens.css|56 个基础及语义令牌，同源生成|
|styles.json / styles.css|8 个文字样式及阴影、动效、布局规则|
|library/manifest.json|组件族、变体轴、属性与页面示例映射|
|library/components.js / components.css|可复用组件实现，无框架依赖|
|visual.css / visual.js|原型视觉层与独立预览模式|
|page-inventory.json|40 页编号、角色、规则、预览与截图映射|
|screens/|40 张真实浏览器截图|
|VERIFICATION.md / GOAL-AUDIT.md|验证范围、证据与目标逐项核对|
|source-baseline.json|原始 D0.2 摘要与业务脚本一致性|

页面默认样例中的数量和身份为虚构数据。此交付用于 UI 评审与前端实施；短信、相机、附件上传、服务端权限、离线持久化和并发控制未实现。

## Figma 来源、续建与验证

2026-09-07 通过 Framelink_Figma_MCP 实际读取既有文件，下载基础规范、按钮和字段 3 张原图，并校准本地字重、字段尺寸与加载态。[当时的来源对照](figma-reference/index.html) 保留为历史快照。

2026-09-08 按用户指令连接 `ju3ayfbw`，实际写入 8 个原生组件集、85 个变体、40 个画板与 10 个组合示例。40 页包含 1,612 个可编辑文字图层及 225 个组件实例，没有整页截图填充；全部页面已导出 PNG 并逐页核对文字与尺寸。详见 [原生 Figma 验证](NATIVE-FIGMA-VERIFICATION.md)。

原生页面是固定视口的静态视觉稿，交互情境仍在本地 `prototype.html`；不把页面 Frame 声称为整页自动布局组件。Button、Field、Status 保留原生组件和自动布局结构，其余复杂内容使用可编辑分组。新图层沿用令牌色值，未新增变量绑定；中文按现有 Noto Sans SC 字号层级校准。

`figma-state.json`、原 Figma API 辅助脚本和 `archive/` 保留历史记录。当前 Figma 节点以 `figma-native/component-map.json`、`screens-map.json`、`composition-map.json` 和 `figma-local-mcp-state.json` 为准。
